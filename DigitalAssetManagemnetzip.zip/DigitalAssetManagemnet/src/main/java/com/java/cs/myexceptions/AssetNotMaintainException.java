package com.java.cs.myexceptions;

public class AssetNotMaintainException extends Exception {
	public AssetNotMaintainException(String message) {
		super(message);
	}

}
